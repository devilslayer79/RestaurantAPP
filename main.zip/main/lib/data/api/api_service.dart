import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:main/data/model/restaurant_response.dart';

class ApiService {
  final String baseUrl = 'https://restaurant-api.dicoding.dev/';
  static const String list = 'list';

  Future<Data> getDataRestaurant() async {
    final respone = await http.get(Uri.parse(baseUrl + list));
    if (respone.statusCode == 200) {
      return Data.fromJson(json.decode(respone.body));
    } else {
      throw Exception('Failed to load data restaurant');
    }
  }

  Future<Detail> getDetailRestaurant(String id) async {
    final respone = await http.get(Uri.parse(baseUrl + "detail/" + id));
    if (respone.statusCode == 200) {
      return Detail.fromJson(json.decode(respone.body));
    } else {
      throw Exception('Failed to load detail restaurant');
    }
  }

  Future<Search> searchRestaurant(String query) async {
    final response = await http.get(Uri.parse(baseUrl + "search?q=" + query));
    if (response.statusCode == 200) {
      return Search.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to Search');
    }
  }
}
