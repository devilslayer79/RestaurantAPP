import 'package:flutter/material.dart';
import 'package:main/data/api/api_service.dart';
import 'package:main/data/model/restaurant_response.dart';

enum RestaurantState { loading, noData, hasData, error }

class ListRestaurantProvider extends ChangeNotifier {
  final ApiService getApiService;

  ListRestaurantProvider({required this.getApiService}) {
    fetchAllRestaurant();
  }

  late Data _dataResto;
  late RestaurantState _restaurantState;
  late String _message = '';

  String get message => _message;
  Data get dataResto => _dataResto;
  RestaurantState get restaurantState => _restaurantState;

  Future<dynamic> fetchAllRestaurant() async {
    try {
      _restaurantState = RestaurantState.loading;
      notifyListeners();
      final restaurant = await getApiService.getDataRestaurant();
      if (restaurant.restaurants.isEmpty) {
        _restaurantState = RestaurantState.noData;
        notifyListeners();
        return _message = 'Empty Data';
      } else {
        _restaurantState = RestaurantState.hasData;
        notifyListeners();
        return _dataResto = restaurant;
      }
    } catch (e) {
      _restaurantState = RestaurantState.error;
      notifyListeners();
      return _message = 'Not connected to the internet...';
    }
  }
}
