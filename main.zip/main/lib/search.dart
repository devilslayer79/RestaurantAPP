import 'package:faker/faker.dart';
import 'package:flutter/material.dart';
import 'package:main/data/model/restaurant.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  TextEditingController _controllerSearch = TextEditingController();
  Widget? searchTextField = Text("List Users");

  bool search = false;
  Color _bgColor = Colors.green;
  List RestaurantElement = [];

  @override
  void initState() {
    super.initState();

    RestaurantElement.addAll(restaurants);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _bgColor,
        //title mulanya adalah text
        title: searchTextField,
        actions: <Widget>[
          //jika search bernilai false maka tampilkan icon search
          //jika search bernilai true maka tampilkan icon close
          (search == false)
              ? IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    setState(() {
                      searchTextField = appSearch(context);
                      _bgColor = Colors.white;
                      search = true;
                    });
                  })
              : IconButton(
                  icon: Icon(
                    Icons.close,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    setState(() {
                      restaurants.clear();
                      RestaurantElement.addAll(restaurants);
                      _controllerSearch.clear();
                    });
                  })
        ],
      ),
      body: ListView.builder(
        itemCount: restaurants.length,
        itemBuilder: (context, int index) {
          return ListTile(
            title: Text(
              restaurants[index],
              style: TextStyle(fontSize: 18),
            ),
          );
        },
      ),
    );
  }

  Widget appSearch(BuildContext context) {
    return TextField(
      controller: _controllerSearch,
      style: TextStyle(color: Colors.black, fontSize: 18),
      decoration: InputDecoration(
          icon: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                setState(() {
                  searchTextField = Text("List Users");
                  search = false;
                  _bgColor = Colors.green;
                  _controllerSearch.clear();
                  restaurants.clear();
                  RestaurantElement.addAll(restaurants);
                });
              }),
          hintText: "Search",
          hintStyle: TextStyle(color: Colors.grey)),
      // setiap ada perubahan, jalankan fungsi _searchName
      onChanged: (name) {
        _searchName(name);
      },
    );
  }

  _searchName(String name) {
    if (name.isNotEmpty) {
      setState(() {
        restaurants.clear();
        //melakukan perulangan/looping
        restaurants.forEach((item) {
          //jika list data ada yang mengandung susunan huruf yang dicari
          //maka masukan ke dalam data list
          if (item.toLowerCase().contains(name.toLowerCase())) {
            RestaurantElement.add(restaurants);
          }
        });
      });
    } else {
      setState(() {
        restaurants.clear();
        RestaurantElement.addAll(restaurants);
      });
    }
  }
}
