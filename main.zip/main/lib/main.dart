import 'package:flutter/material.dart';
import 'package:main/common/font.dart';

import 'package:main/data/model/restaurant.dart';
import 'package:main/splash.dart';

import 'package:main/ui/detail_page.dart';
import 'package:main/ui/list_page.dart';

import 'package:main/data/model/restaurant_detail.dart';
import 'package:main/data/model/restaurant_response.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant App',
      theme: ThemeData(
        brightness: Brightness.dark,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: myTextTheme,
        appBarTheme: const AppBarTheme(elevation: 0),
      ),
      initialRoute: Splash.routeName,
      routes: {
        Splash.routeName: (context) => const Splash(),
        NewListPage.routeName: (context) => const NewListPage(),
        RestaurantDetailPage.routeName: (context) => RestaurantDetailPage(
              restaurant: ModalRoute.of(context)?.settings.arguments
                  as RestaurantElement,
            ),
      },
    );
  }
}
